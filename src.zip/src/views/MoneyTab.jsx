import React, { useEffect, useMemo, useState } from 'react'

// Read helpers
function read(key, fallback){ try{ return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)) }catch{ return fallback } }
function write(key, val){ localStorage.setItem(key, JSON.stringify(val)) }

// Your completed jobs list (you said you already manage Future/Previous yourself)
function readPrevious(){ return read('previousAssignments', []) }

// Manual money entries live here (by assignment id)
const MONEY_KEY = 'moneyManual'  // { [assignmentId]: { worker1:number, worker2:number, salesman:number } }

export default function MoneyTab(){
  const [rows, setRows] = useState(readPrevious())
  const [money, setMoney] = useState(read(MONEY_KEY, {}))

  // Keep table live with what you’re storing in previousAssignments elsewhere
  useEffect(()=>{
    const t = setInterval(()=> setRows(readPrevious()), 3000)
    return ()=>clearInterval(t)
  },[])

  const setVal = (id, field, raw) => {
    const v = raw === '' ? '' : Number(raw)
    setMoney(prev => {
      const next = { ...prev, [id]: { ...(prev[id]||{}), [field]: (isNaN(v) ? '' : v) } }
      return next
    })
  }

  const saveAll = () => {
    write(MONEY_KEY, money)
    alert('Money saved.')
  }

  const totals = useMemo(()=>{
    const t = { worker1:0, worker2:0, salesman:0 }
    for (const r of rows){
      const m = money[r.id] || {}
      t.worker1 += Number(m.worker1 || 0)
      t.worker2 += Number(m.worker2 || 0)
      t.salesman += Number(m.salesman || 0)
    }
    for (const k of Object.keys(t)) t[k] = +t[k].toFixed(2)
    return t
  }, [rows, money])

  return (
    <div className="grid">
      <div className="card">
        <h2 className="section-title">Money (Manual Ledger)</h2>
        <p className="muted" style={{marginTop:0, marginBottom:12}}>
          Type the payout amounts yourself below. No auto-percentages are calculated here.
        </p>

        <table className="table">
          <thead>
            <tr>
              <th>Date &amp; Time</th>
              <th>Customer</th>
              <th>Price</th>
              <th>Worker 1 ($)</th>
              <th>Worker 2 ($)</th>
              <th>Salesman ($)</th>
            </tr>
          </thead>
          <tbody>
            {rows.length===0 && (
              <tr><td colSpan={6} style={{color:'#64748b'}}>No completed jobs yet.</td></tr>
            )}
            {rows.map(r=>{
              const m = money[r.id] || {}
              const whenText = r.when || (r.whenTs ? new Date(r.whenTs).toLocaleString() : '-')
              return (
                <tr key={r.id}>
                  <td>{whenText}</td>
                  <td>{r.customerName || r.customer || '-'}</td>
                  <td>{r.price != null ? `$${Number(r.price).toFixed(2)}` : '-'}</td>
                  <td>
                    <input
                      inputMode="decimal"
                      placeholder="0.00"
                      value={m.worker1 ?? ''}
                      onChange={e=>setVal(r.id,'worker1',e.target.value)}
                      style={{width:100}}
                    />
                  </td>
                  <td>
                    <input
                      inputMode="decimal"
                      placeholder="0.00"
                      value={m.worker2 ?? ''}
                      onChange={e=>setVal(r.id,'worker2',e.target.value)}
                      style={{width:100}}
                    />
                  </td>
                  <td>
                    <input
                      inputMode="decimal"
                      placeholder="0.00"
                      value={m.salesman ?? ''}
                      onChange={e=>setVal(r.id,'salesman',e.target.value)}
                      style={{width:100}}
                    />
                  </td>
                </tr>
              )
            })}
          </tbody>
          <tfoot>
            <tr>
              <th colSpan={3} style={{textAlign:'right'}}>Totals</th>
              <th>${totals.worker1.toFixed(2)}</th>
              <th>${totals.worker2.toFixed(2)}</th>
              <th>${totals.salesman.toFixed(2)}</th>
            </tr>
          </tfoot>
        </table>

        <div className="toolbar" style={{marginTop:12}}>
          <button className="btn" onClick={saveAll}>Save</button>
        </div>
      </div>
    </div>
  )
}