import React, { useEffect, useState } from "react";

/* ===== storage helpers ===== */
function read(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
  catch { return fallback; }
}
function write(key, val) { localStorage.setItem(key, JSON.stringify(val)); }
function getUser() { try { return JSON.parse(localStorage.getItem("pane_user") || "null"); } catch { return null; } }
function usersAll() { return read("users_seed", []); }

/* ===== seller calendar data =====
   Stored under 'seller_calendar' as [{ email, dateISO, hours }]
*/
function getCal() { return read("seller_calendar", []); }
function setCal(rows) { write("seller_calendar", rows); }
function setHours(email, dateISO, hours) {
  const all = getCal().filter(r => !(r.email === email && r.dateISO === dateISO));
  all.push({ email, dateISO, hours: (hours || "").trim() });
  setCal(all);
}
function readHours(email, dateISO) {
  const hit = getCal().find(r => r.email === email && r.dateISO === dateISO);
  return hit?.hours || "";
}

/* ===== 14-day rolling window ===== */
function startOfDay(d) { const x = new Date(d); x.setHours(0,0,0,0); return x; }
function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate()+n); return x; }
function days14() { const t = startOfDay(new Date()); return Array.from({ length: 14 }, (_, i) => addDays(t, i)); }
function toISO(d) { return startOfDay(d).toISOString().slice(0,10); }
function fmtColHeader(d) { return d.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" }); }

/* Only show sellers & hybrids (admin can edit all but doesn't get a row) */
function calendarUsers() {
  const all = usersAll();
  return all.filter(u => u && (u.role === "seller" || u.role === "hybrid"));
}

export default function SellersCalendar() {
  const me = getUser();
  const isAdmin = me?.role === "admin";
  const myEmail = me?.email || "";
  const allUsers = calendarUsers();

  const [dates, setDates] = useState(days14());
  const [version, setVersion] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setVersion(v => v+1), 1500);
    return () => clearInterval(t);
  }, []);

  const onEdit = (email, dateObj, val) => {
    const dateISO = toISO(dateObj);
    setHours(email, dateISO, val);
    setVersion(v => v+1);
  };

  return (
    <div className="grid">
      <div className="card">
        <h2 className="section-title">Sellers Calendar (14-day rolling)</h2>
        <div style={{ overflowX: "auto" }}>
          <table className="table" style={{ minWidth: 960 }}>
            <thead>
              <tr>
                <th style={{ width: 200 }}>Salesman</th>
                {dates.map((d) => (
                  <th key={d.toISOString()}>{fmtColHeader(d)}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {allUsers.length === 0 && (
                <tr>
                  <td colSpan={1 + dates.length} style={{ color: "#64748b" }}>
                    No sellers yet.
                  </td>
                </tr>
              )}

              {allUsers.map((u) => (
                <tr key={u.email}>
                  <td style={{ fontWeight: u.email === myEmail ? 700 : 500 }}>
                    {u.name}
                  </td>

                  {dates.map((d) => {
                    const dateISO = toISO(d);
                    const value = readHours(u.email, dateISO);
                    const canEdit = isAdmin || u.email === myEmail; // admin edits all; others only their row

                    return (
                      <td key={u.email + dateISO}>
                        <input
                          value={value}
                          onChange={(e) => onEdit(u.email, d, e.target.value)}
                          placeholder="hours"
                          disabled={!canEdit}
                          style={{
                            width: "100%",
                            padding: "6px 8px",
                            border: "1px solid #e6eef6",
                            borderRadius: 8,
                            outline: "none",
                          }}
                        />
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}