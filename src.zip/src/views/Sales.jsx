import React, { useEffect, useMemo, useState } from 'react'

function getUser(){ try{ return JSON.parse(localStorage.getItem('pane_user')||'null') }catch{ return null } }
function readSales(){ try{ return JSON.parse(localStorage.getItem('sales')||'[]') }catch{ return [] } }
function writeSales(rows){ localStorage.setItem('sales', JSON.stringify(rows)) }

export default function Sales(){
  const user = getUser()
  const [sales, setSales] = useState(readSales())
  const [form, setForm] = useState({
    name: '', phone: '', price: '', address: '', neighborhood: '', notes: '', date: ''
  })

  useEffect(()=>{ setSales(readSales()) },[])

  const mySales = useMemo(()=>{
    if(!user) return []
    if(user.role === 'admin') return sales.map(s=>({...s, isAdminSale: s.sellerEmail === user.email}))
    return sales.filter(s=>s.sellerEmail === user.email)
  },[sales,user])

  const addSale = ()=>{
    if(!form.name || !form.phone || !form.price || !form.address){
      alert('Name, phone, price, and address are required.')
      return
    }
    const all = readSales()
    const id = Date.now()
    all.push({
      id,
      ...form,
      sellerEmail: user.email,
      sellerName: user.name,
      status: 'workers not assigned',
      createdAt: Date.now()
    })
    writeSales(all)
    setSales(all)
    setForm({ name:'', phone:'', price:'', address:'', neighborhood:'', notes:'', date:'' })
    alert('Sale added!')
  }

  const statusLabel = s => s.status || 'workers not assigned'

  return (
    <div className="grid">
      <div className="card">
        <h2 className="section-title">Record a New Sale</h2>
        <div className="grid" style={{gridTemplateColumns:'repeat(2,1fr)', gap:10}}>
          <input placeholder="Customer Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
          <input placeholder="Phone" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/>
          <input placeholder="Price ($)" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/>
          <input placeholder="Address" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/>
          <input placeholder="Neighborhood" value={form.neighborhood} onChange={e=>setForm({...form,neighborhood:e.target.value})}/>
          <input placeholder="Date & Time" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/>
          <textarea placeholder="Notes (optional)" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} style={{gridColumn:'1 / span 2'}}/>
        </div>
        <div className="toolbar" style={{marginTop:10}}>
          <button className="btn" onClick={addSale}>Add Sale</button>
        </div>
      </div>

      <div className="card">
        <h2 className="section-title">All Sales</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Customer</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Neighborhood</th>
              <th>Price</th>
              <th>Status</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {mySales.length === 0 && (
              <tr><td colSpan={8} style={{color:'#64748b'}}>No sales yet.</td></tr>
            )}
            {[...mySales].sort((a,b)=>b.createdAt - a.createdAt).map(s=>(
              <tr key={s.id} style={user.role==='admin' && s.sellerEmail===user.email ? {fontWeight:'bold'} : {}}>
                <td>{new Date(s.createdAt).toLocaleDateString()}</td>
                <td>{s.name}</td>
                <td>{s.phone}</td>
                <td>{s.address}</td>
                <td>{s.neighborhood || '-'}</td>
                <td>${s.price}</td>
                <td>{statusLabel(s)}</td>
                <td>{s.notes || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}