// src/views/WorkerPayments.jsx
import React, { useMemo } from "react";

/* ===== storage helpers ===== */
function read(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
  catch { return fallback; }
}
function getUser(){ try{ return JSON.parse(localStorage.getItem('pane_user')||'null') }catch{ return null } }
function readSales(){ return read('sales', []) }
function readAssignments(){ return read('assignments', []) }

/* ===== small date/time helpers ===== */
function toDate(v){
  if(!v) return null;
  const d = typeof v === 'number' ? new Date(v) : new Date(String(v));
  return isNaN(d) ? null : d;
}
function fmtDateTime(v){
  const d = toDate(v);
  return d ? d.toLocaleString([], { month:'short', day:'numeric', hour:'numeric', minute:'2-digit' }) : '-';
}

/* ===== payday helpers ===== */
function nextFriday(){
  const d = new Date();
  const day = d.getDay();
  const delta = (5 - day + 7) % 7 || 7;
  const n = new Date(d);
  n.setDate(d.getDate() + delta);
  n.setHours(0,0,0,0);
  return n;
}
function fmtNextFriday(){
  const n = nextFriday();
  return n.toLocaleDateString([], { weekday:'short', month:'short', day:'numeric' });
}

/* ===== parse "when" into hours worked ===== */
function hoursFromWhenString(str){
  if(!str) return null;
  const s = String(str).toLowerCase().replace(/[–—]/g, '-');
  const parts = s.split(',').map(p=>p.trim()).filter(Boolean);
  let totalMin = 0;
  for(const p of parts){
    const m = p.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*-\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);
    if(!m) continue;
    let [ , h1, m1, a1, h2, m2, a2 ] = m;
    let hh1 = parseInt(h1,10), mm1 = m1?parseInt(m1,10):0;
    let hh2 = parseInt(h2,10), mm2 = m2?parseInt(m2,10):0;
    let H1 = hh1%12, H2 = hh2%12;
    if(a1==='pm') H1+=12;
    if(a2==='pm') H2+=12;
    if(!a1 && a2) H1 = (a2==='pm' ? (hh1%12)+12 : hh1%12);
    if(a1 && !a2) H2 = (a1==='pm' ? (hh2%12)+12 : hh2%12);
    if(H2 <= H1) H2 += 24;
    totalMin += (H2*60+mm2)-(H1*60+mm1);
  }
  if(totalMin<=0) return null;
  return +(totalMin/60).toFixed(2);
}

export default function WorkerPayments(){
  const me = getUser();
  const sales = readSales();
  const assignments = readAssignments();
  if(!me) return <div className="grid"><div className="card">Please log in.</div></div>;

  const myRows = useMemo(()=>{
    const mine = assignments.filter(a => a.workerEmail===me.email || a.worker2Email===me.email);
    return mine.map(a=>{
      const sale = sales.find(s=> String(s.id)===String(a.saleId));
      const price = sale?.price ? Number(sale.price) : null;
      const myShare = price!=null ? Number((price*0.2).toFixed(2)) : null;
      const workedDate = toDate(a.when) && toDate(a.when) < new Date() ? toDate(a.when) : null;
      const hrs = hoursFromWhenString(a.when || '');
      return {
        id:a.id,
        customer: sale?.name || a.saleId,
        dateWorkedLabel: workedDate ? fmtDateTime(workedDate) : '-',
        myShare,
        timeWorkedHours: hrs,
      };
    });
  }, [assignments, sales, me?.email]);

  const nextPayAmount = useMemo(()=>(
    myRows.reduce((s,r)=> s + ((r.dateWorkedLabel!=='-' && r.myShare)?r.myShare:0), 0)
  ), [myRows]);

  const totalHours = useMemo(()=>(
    myRows.reduce((s,r)=> s + ((r.dateWorkedLabel!=='-' && r.timeWorkedHours)?r.timeWorkedHours:0), 0)
  ), [myRows]);

  return (
    <div className="grid">
      <div className="card">
        <h2 className="section-title">Payments</h2>
        <div className="row" style={{gap:12,flexWrap:'wrap'}}>
          <div className="chip" style={{fontWeight:700}}>
            Next Paycheck $: ${nextPayAmount.toFixed(2)}
          </div>
          <div className="chip" style={{fontWeight:700}}>
            Next Paycheck Date: {fmtNextFriday()}
          </div>
          <div className="chip" style={{fontWeight:700}}>
            Total Hours This Paycheck: {totalHours.toFixed(2)}h
          </div>
        </div>
      </div>

      <div className="card">
        <h2 className="section-title">My Jobs & Earnings</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Date Worked</th>
              <th>Customer</th>
              <th>Money for You</th>
              <th>Time Worked</th>
            </tr>
          </thead>
          <tbody>
            {myRows.length===0 && <tr><td colSpan={4} style={{color:'#64748b'}}>No jobs yet.</td></tr>}
            {myRows.map(r=>(
              <tr key={r.id}>
                <td>{r.dateWorkedLabel}</td>
                <td>{r.customer}</td>
                <td>{r.myShare!=null ? `$${r.myShare.toFixed(2)}` : '-'}</td>
                <td>{typeof r.timeWorkedHours==='number' ? `${r.timeWorkedHours.toFixed(2)}h` : '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}