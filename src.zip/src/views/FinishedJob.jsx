// src/views/FinishedJob.jsx
import React, { useMemo, useState } from 'react'

/* ===== storage helpers ===== */
function read(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)) }
  catch { return fallback }
}
function write(key, val) { localStorage.setItem(key, JSON.stringify(val)) }
function getUser() { try { return JSON.parse(localStorage.getItem('pane_user') || 'null') } catch { return null } }

/* ===== finished jobs live here =====
   key: 'finishedJobs'
   shape: { id, workerEmail, workerName, customer, paidYes, paidHow, happy, notes, hours, minutes, submittedAtISO }
*/
const KEY = 'finishedJobs'

export default function FinishedJob(){
  const me = getUser()
  const [rows, setRows] = useState(()=> read(KEY, []))

  const [form, setForm] = useState({
    customer: '',
    paidYes: '',
    paidHow: 'Venmo',   // default to Venmo per request
    happy: '5',
    notes: '',
    hours: '',
    minutes: '',
  })

  const onChange = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const onSubmit = () => {
    const customer = (form.customer || '').trim()
    const paidYes = (form.paidYes || '').trim()  // 'Yes' | 'No'
    const paidHow = (form.paidHow || '').trim()  // 'Venmo' | 'Cash' | 'Check (made out to Ghaven Mittal)'
    const happy = (form.happy || '').trim()      // '1'..'5'
    const hours = String(form.hours || '').trim()
    const minutes = String(form.minutes || '').trim()

    if (!customer) { alert('Customer name is required.'); return }
    if (!paidYes) { alert('Select whether the customer paid.'); return }
    if (!paidHow) { alert('Select how the customer paid.'); return }
    if (!happy) { alert('Select how happy (1–5).'); return }
    if (hours === '' && minutes === '') { alert('Enter time worked (hours and/or minutes).'); return }

    const h = Math.max(0, Number.isFinite(+hours) ? +hours : 0)
    const m = Math.max(0, Number.isFinite(+minutes) ? +minutes : 0)

    const rec = {
      id: Date.now(),
      workerEmail: me?.email || '',
      workerName: me?.name || '',
      customer,
      paidYes,
      paidHow,
      happy: Number(happy),
      notes: (form.notes || '').trim(),
      hours: h,
      minutes: m,
      submittedAtISO: new Date().toISOString(),
    }

    const next = [...read(KEY, []), rec]
    write(KEY, next)
    setRows(next)

    setForm({
      customer: '',
      paidYes: '',
      paidHow: 'Venmo',
      happy: '5',
      notes: '',
      hours: '',
      minutes: '',
    })

    alert('Finished job submitted.')
  }

  if(!me){
    return <div className="grid"><div className="card">Please log in again.</div></div>
  }

  return (
    <div className="grid">
      <div className="card">
        {/* Title tightened up */}
        <h2 className="section-title" style={{ marginTop: 4, marginBottom: 6 }}>Finished Job</h2>
        <div
          style={{
            fontSize: 12,
            fontWeight: 800,
            letterSpacing: 0.3,
            textTransform: 'uppercase',
            color: 'var(--danger)',
            marginBottom: 8
          }}
        >
          MUST COMPLETE BEFORE LEAVING SITE BY BOTH WORKERS
        </div>

        {/* Form with tighter spacing between title and first field */}
        <div className="grid" style={{ gridTemplateColumns:'repeat(2, minmax(220px, 1fr))', gap:8 }}>
          <div style={{ gridColumn:'1 / -1' }}>
            <label>Customer Name*</label>
            <input value={form.customer} onChange={e=>onChange('customer', e.target.value)} placeholder="Customer full name" />
          </div>

          <div>
            <label>Paid?*</label>
            <select value={form.paidYes} onChange={e=>onChange('paidYes', e.target.value)}>
              <option value="">— Select —</option>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>

          <div>
            <label>How Paid?* (Venmo / Cash / Check)</label>
            <select value={form.paidHow} onChange={e=>onChange('paidHow', e.target.value)}>
              <option value="Venmo">Venmo</option>
              <option value="Cash">Cash</option>
              <option value="Check (made out to Ghaven Mittal)">Check (made out to Ghaven Mittal)</option>
            </select>
          </div>

          <div>
            <label>How Happy? (1–5)*</label>
            <select value={form.happy} onChange={e=>onChange('happy', e.target.value)}>
              <option value="5">5 — Very happy</option>
              <option value="4">4</option>
              <option value="3">3 — Neutral</option>
              <option value="2">2</option>
              <option value="1">1 — Not happy</option>
            </select>
          </div>

          <div>
            <label>Time Worked*</label>
            <div className="row" style={{ gap:8 }}>
              <input
                value={form.hours}
                onChange={e=>onChange('hours', e.target.value)}
                inputMode="numeric"
                placeholder="Hours"
              />
              <input
                value={form.minutes}
                onChange={e=>onChange('minutes', e.target.value)}
                inputMode="numeric"
                placeholder="Minutes"
              />
            </div>
          </div>

          <div style={{ gridColumn:'1 / -1' }}>
            <label>Notes (optional)</label>
            <textarea rows={3} value={form.notes} onChange={e=>onChange('notes', e.target.value)} placeholder="Anything the admin should know..." />
          </div>
        </div>

        <div className="toolbar" style={{ marginTop:10 }}>
          <button className="btn" onClick={onSubmit}>Submit Finished Job</button>
        </div>

        <p className="muted" style={{ marginTop:6, fontSize:12 }}>
          A timestamp will be saved automatically and visible to admin.
        </p>
      </div>

      {/* Per request: Removed "My Submitted Jobs" table */}
    </div>
  )
}