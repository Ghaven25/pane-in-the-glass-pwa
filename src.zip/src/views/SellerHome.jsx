import React, { useMemo } from "react";

const DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

function getUser(){ try{ return JSON.parse(localStorage.getItem("pane_user")||"null") }catch{ return null } }
function readAvail(){ try{ return JSON.parse(localStorage.getItem("availability")||"[]") }catch{ return [] } }
function readAssignments(){ try{ return JSON.parse(localStorage.getItem("assignments")||"[]") }catch{ return [] } }
function readSales(){ try{ return JSON.parse(localStorage.getItem("sales")||"[]") }catch{ return [] } }

export default function SellerHome(){
  const me = getUser();
  const avail = readAvail();
  const assignments = readAssignments();
  const sales = readSales();

  // My snapshot (upcoming for *this* seller)
  const myUpcoming = useMemo(()=>{
    // An assignment “belongs” to a seller if its sale was created by that seller
    return assignments
      .map(a=>{
        const sale = sales.find(s=>String(s.id)===String(a.saleId));
        if (!sale) return null;
        if (sale.sellerEmail !== me?.email) return null;
        return {
          id: a.id,
          customer: sale.name,
          phone: sale.phone,
          address: sale.address,
          worker1: a.workerEmail,
          worker2: a.worker2Email,
          when: a.when || "-"
        };
      })
      .filter(Boolean);
  }, [assignments, sales, me?.email]);

  const myWeek = useMemo(()=>{
    const rows = avail.filter(a=>a.userEmail===me?.email && a.role==="seller");
    const map = {};
    for (const d of DAYS){
      map[d] = rows.find(r=>r.day===d)?.hours || "";
    }
    return map;
  }, [avail, me?.email]);

  // Offered assignments — for sellers we’ll show nothing or (optionally) leave empty list
  const offered = []; // by design: sellers don’t accept offers here

  return (
    <div className="grid">
      <div className="card">
        <h2 className="section-title">My Snapshot</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Customer</th><th>Phone</th><th>Address</th><th>Worker 1</th><th>Worker 2</th><th>Date &amp; Time</th>
            </tr>
          </thead>
          <tbody>
            {myUpcoming.length===0 && <tr><td colSpan={6} style={{color:'#64748b'}}>No upcoming assignments.</td></tr>}
            {myUpcoming.map(r=>(
              <tr key={r.id}>
                <td>{r.customer}</td>
                <td>{r.phone || "-"}</td>
                <td>{r.address || "-"}</td>
                <td>{r.worker1 || "-"}</td>
                <td>{r.worker2 || "-"}</td>
                <td>{r.when}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2 className="section-title">My Weekly Hours (read-only)</h2>
        <table className="table">
          <thead>
            <tr>{DAYS.map(d=><th key={d}>{d}</th>)}</tr>
          </thead>
          <tbody>
            <tr>
              {DAYS.map(d=>(
                <td key={d} style={{fontSize:12}}>{myWeek[d] || "-"}</td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2 className="section-title">Offered Assignments</h2>
        <table className="table">
          <thead>
            <tr><th>Customer</th><th>Phone</th><th>Address</th><th>Worker 1</th><th>Worker 2</th><th>Date &amp; Time</th></tr>
          </thead>
          <tbody>
            {offered.length===0 && <tr><td colSpan={6} style={{color:'#64748b'}}>No offers.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}