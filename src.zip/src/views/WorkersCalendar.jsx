// src/views/WorkersCalendar.jsx
import React, { useEffect, useMemo, useState } from "react";

/* ===== storage helpers ===== */
function read(key, fallback) { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch { return fallback; } }
function write(key, val) { localStorage.setItem(key, JSON.stringify(val)); }
function getUser(){ try{ return JSON.parse(localStorage.getItem('pane_user')||'null') }catch{ return null } }
function usersAll(){ return read('users_seed', []) }
function readAssignments(){ return read('assignments', []) }
function readSales(){ return read('sales', []) }

/* ===== worker day-specific calendar =====
   Stored under 'worker_calendar' as [{ email, dateISO:'YYYY-MM-DD', hours }]
*/
function getWCal(){ return read('worker_calendar', []) }
function setWCal(rows){ write('worker_calendar', rows) }
function setHours(email, dateISO, hours){
  const all = getWCal().filter(r => !(r.email===email && r.dateISO===dateISO))
  all.push({ email, dateISO, hours: (hours||'').trim() })
  setWCal(all)
}
function readHours(email, dateISO){
  const hit = getWCal().find(r => r.email===email && r.dateISO===dateISO)
  return hit?.hours || ''
}

/* ===== dates: rolling 14 days (vertical) ===== */
function startOfDay(d){ const x=new Date(d); x.setHours(0,0,0,0); return x }
function addDays(d,n){ const x=new Date(d); x.setDate(x.getDate()+n); return x }
function days14(){ const t = startOfDay(new Date()); return Array.from({length:14},(_,i)=> addDays(t,i)) }
function toISO(d){ return startOfDay(d).toISOString().slice(0,10) }
function fmtRowHeader(d){ return d.toLocaleDateString([], { weekday:'short', month:'short', day:'numeric' }) }
function shortDow(d){ return d.toLocaleDateString([], { weekday:'short' }).slice(0,3) }

/* ===== worker list (workers + hybrids only) ===== */
function workerUsers(){
  const all = usersAll();
  return all.filter(u => u && (u.role==='worker' || u.role==='hybrid'))
}

export default function WorkersCalendar(){
  const me = getUser();
  const myEmail = me?.email || '';
  const isMe = (email)=> (email||'').toLowerCase() === (myEmail||'').toLowerCase();

  const allUsers = workerUsers();
  const [dates] = useState(days14());

  // live-ish snapshots
  const [assignments] = useState(readAssignments());
  const [sales] = useState(readSales());

  // map of scheduled jobs per worker/date
  const scheduledLookup = useMemo(()=>{
    const map = new Map(); // key: email|YYYY-MM-DD -> [{customer, when}]
    const SHORTS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    for(const a of assignments){
      for(const email of [a.workerEmail, a.worker2Email]){
        if(!email) continue;
        const sale = sales.find(s=> String(s.id)===String(a.saleId));
        const label = String(a.when||'').toLowerCase();
        const short = SHORTS.find(s=> label.includes(s.toLowerCase()));
        for (const d of dates){
          if (short && shortDow(d) === short){
            const iso = toISO(d);
            const k = `${email}|${iso}`;
            const arr = map.get(k) || [];
            arr.push({ customer: sale?.name || a.saleId, when: a.when || '-' });
            map.set(k, arr);
          }
        }
      }
    }
    return map;
  }, [assignments, sales, dates]);

  /* ====== EDIT RULE: lock the NEXT 3 DAYS (today + next 2), or if already scheduled ====== */
  function withinNext3Days(d){
    const today = startOfDay(new Date());
    const tgt   = startOfDay(d);
    const days = Math.floor((tgt - today) / (24*60*60*1000));
    return days <= 2; // lock day 0 (today), day 1 (tomorrow), day 2 (the day after)
  }

  function canEditCell(email, dateObj){
    if (!isMe(email)) return false;                           // others are read-only
    const iso = toISO(dateObj);
    if ((scheduledLookup.get(`${email}|${iso}`) || []).length > 0) return false; // job assigned -> lock
    if (withinNext3Days(dateObj)) return false;               // locked window
    return true;
  }

  const onEdit = (email, dateObj, val)=>{
    const dateISO = toISO(dateObj);
    setHours(email, dateISO, val);
  };

  return (
    <div className="grid">
      <div className="card">
        <h2 className="section-title">My Calendar (2-Week Rolling)</h2>
        <div style={{ overflowX:"auto" }}>
          <table className="table" style={{ minWidth: Math.max(800, 220 + allUsers.length*200) }}>
            <thead>
              <tr>
                <th style={{width:220}}>Date</th>
                {allUsers.map(u=>(
                  <th key={u.email} style={{width:200}}>
                    {u.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {dates.map(d=>{
                const dateISO = toISO(d);
                return (
                  <tr key={dateISO}>
                    <td style={{fontWeight:600}}>{fmtRowHeader(d)}</td>
                    {allUsers.map(u=>{
                      const isoKey = `${u.email}|${dateISO}`;
                      const value = readHours(u.email, dateISO);
                      const sched = scheduledLookup.get(isoKey) || [];
                      const editable = canEditCell(u.email, d);

                      return (
                        <td key={u.email+dateISO}>
                          <input
                            value={value}
                            onChange={(e)=> onEdit(u.email, d, e.target.value)}
                            placeholder={editable ? "hours" : (isMe(u.email) ? "locked" : "read-only")}
                            disabled={!editable}
                            style={{
                              width:'100%',
                              padding:'6px 8px',
                              border:'1px solid var(--border)',
                              borderRadius:8,
                              outline:'none',
                              background:'var(--card)',
                              color:'var(--text)',
                              opacity: editable ? 1 : 0.85,
                              cursor: editable ? 'text' : 'not-allowed'
                            }}
                          />
                          {sched.length>0 && (
                            <div style={{marginTop:6, fontSize:12, color:'var(--muted)'}}>
                              {sched.map((s,i)=>(
                                <div key={i}>• {s.customer} — {s.when}</div>
                              ))}
                            </div>
                          )}
                        </td>
                      )
                    })}
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}