import React, { useEffect, useMemo, useState } from 'react'

/** ---------- storage helpers ---------- */
function readSales(){ try{ return JSON.parse(localStorage.getItem('sales')||'[]') }catch{ return [] } }
function writeSales(rows){ localStorage.setItem('sales', JSON.stringify(rows)) }
function readAvail(){ try{ return JSON.parse(localStorage.getItem('availability')||'[]') }catch{ return [] } }
function readUsers(){ try{ return JSON.parse(localStorage.getItem('users_seed')||'[]') }catch{ return [] } }
function readAssignments(){ try{ return JSON.parse(localStorage.getItem('assignments')||'[]') }catch{ return [] } }
function writeAssignments(rows){ localStorage.setItem('assignments', JSON.stringify(rows)) }

const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']

/** ---------- date helpers ---------- */
const fmtDateOnly = (t) => {
  if(!t) return '-'
  const d = typeof t === 'number' ? new Date(t) : new Date(String(t))
  if (isNaN(d.getTime())) return '-'
  return d.toLocaleDateString([], {month:'short', day:'numeric'})
}
const startOfWeek = (d=new Date())=>{
  const x = new Date(d); const day = (x.getDay()+6)%7; x.setDate(x.getDate()-day); x.setHours(0,0,0,0); return x
}
const endOfWeek = (d=new Date())=>{
  const s = startOfWeek(d); const e = new Date(s); e.setDate(s.getDate()+7); e.setMilliseconds(-1); return e
}
const inThisWeek = (ts)=>{
  if(!ts) return false
  const d = typeof ts === 'number' ? new Date(ts) : new Date(String(ts))
  if (isNaN(d.getTime())) return false
  return d >= startOfWeek() && d <= endOfWeek()
}

/** ---------- availability helpers ---------- */
function getWeeklyHours(email, role){
  const all = readAvail()
  const mine = all.filter(a => a.userEmail === email && a.role === role)
  const map = {}
  for (const d of DAYS){
    map[d] = mine.find(m=>m.day===d)?.hours || ''
  }
  return map
}

/** ---------- reminders (simple) ---------- */
function pushReminder(title, body){
  try{
    if (!('Notification' in window)) { alert(body); return }
    if (Notification.permission === 'granted'){
      new Notification(title, { body })
    } else if (Notification.permission !== 'denied'){
      Notification.requestPermission().then(perm=>{
        if (perm === 'granted') new Notification(title, { body })
        else alert(body)
      })
    } else {
      alert(body)
    }
  }catch{
    alert(body)
  }
}
function nextShift(email, role){
  const week = getWeeklyHours(email, role)
  const jsDow = new Date().getDay() // Sun=0..Sat=6
  const todayMon0 = (jsDow+6)%7
  for(let i=0;i<14;i++){
    const idx = (todayMon0 + i) % 7
    const dayName = DAYS[idx]
    const hours = (week[dayName]||'').trim()
    if (hours && hours.toLowerCase()!=='off'){
      const d = startOfWeek(); d.setDate(d.getDate()+idx)
      const dayLabel = d.toLocaleDateString([], {weekday:'short', month:'short', day:'numeric'})
      return `${dayLabel}, ${hours}`
    }
  }
  return null
}

/** =======================================================================
 *  AdminAssign (Future) — SIMPLE (non-rolling)
 *  ======================================================================= */
export default function AdminAssign(){
  const [sales, setSales] = useState(readSales())
  const [assignments, setAssignments] = useState(readAssignments())
  const users = readUsers()

  const workers  = useMemo(()=> users.filter(u=>u.role==='worker'||u.role==='hybrid'), [users])
  const salesmen = useMemo(()=> users.filter(u=>u.role==='seller'||u.role==='hybrid'||u.role==='admin'), [users])

  useEffect(()=>{
    setSales(readSales())
    setAssignments(readAssignments())
  },[])

  const unassigned = useMemo(()=> sales.filter(s => s.status === 'unassigned'), [sales])

  /** ---------------- assign form ---------------- */
  const [form, setForm] = useState({
    saleId: '',
    worker1: '',
    worker2: '',
    when: ''
  })

  const doAssign = ()=>{
    if (!form.saleId || !form.worker1 || !form.worker2){
      alert('Pick a customer and two workers.'); return
    }
    const allSales = readSales()
    const idx = allSales.findIndex(s => String(s.id) === String(form.saleId))
    if (idx === -1){ alert('Customer not found.'); return }

    const w1 = users.find(u=>u.email===form.worker1)
    const w2 = users.find(u=>u.email===form.worker2)

    allSales[idx] = {
      ...allSales[idx],
      status: 'assigned',
      assignedTo: `${w1?.name||form.worker1} & ${w2?.name||form.worker2}`,
      when: form.when || ''
    }
    writeSales(allSales)
    setSales(allSales)

    const nextA = [
      ...readAssignments(),
      {
        id: Date.now(),
        saleId: form.saleId,
        workerEmail: form.worker1,
        worker2Email: form.worker2,
        when: form.when || '',
        createdAt: Date.now()
      }
    ]
    writeAssignments(nextA)
    setAssignments(nextA)

    setForm({ saleId:'', worker1:'', worker2:'', when:'' })
    alert('Assigned.')
  }

  /** ---------------- snapshots ---------------- */
  const salesmanSnapshot = useMemo(()=>{
    return salesmen.map(sman=>{
      const mine = sales.filter(x=>x.sellerEmail===sman.email && inThisWeek(x.createdAt))
      const names = mine.map(x=>x.name).filter(Boolean)
      return {
        ...sman,
        weekHours: getWeeklyHours(sman.email, 'seller'),
        soldCount: mine.length,
        soldNames: names
      }
    })
  }, [salesmen, sales])

  const workerSnapshot = useMemo(()=>{
    return workers.map(w=>{
      const myA = assignments.filter(a=>a.workerEmail===w.email || a.worker2Email===w.email)
      const customers = myA.map(a=>{
        const sale = sales.find(s=>String(s.id)===String(a.saleId))
        return sale?.name || '(customer)'
      }).filter(Boolean)
      const whens = myA.map(a=>a.when).filter(Boolean)
      return {
        ...w,
        isScheduled: myA.length>0 ? 'Yes' : 'No',
        customers, whens,
        weekHours: getWeeklyHours(w.email, 'worker')
      }
    })
  }, [workers, assignments, sales])

  return (
    <div className="grid">
      {/* Unassigned customers */}
      <div className="card">
        <h2 className="section-title">Unassigned Customers</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Customer</th><th>Salesman</th><th>Phone</th><th>Address</th><th>Price</th><th>Notes</th><th>Date</th>
            </tr>
          </thead>
          <tbody>
            {unassigned.length===0 && <tr><td colSpan={7} style={{color:'#64748b'}}>No unassigned customers.</td></tr>}
            {unassigned.map(s=>(
              <tr key={s.id}>
                <td>{s.name}</td>
                <td>{s.sellerName} ({s.sellerEmail})</td>
                <td>{s.phone}</td>
                <td>{s.address}</td>
                <td>{s.price ? `$${s.price}` : '-'}</td>
                <td>{s.notes || '-'}</td>
                <td>{fmtDateOnly(s.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="grid" style={{marginTop:12}}>
          <div className="row">
            <div style={{flex:2}}>
              <label>Select Customer</label>
              <select value={form.saleId} onChange={e=>setForm({...form, saleId:e.target.value})}>
                <option value="">—</option>
                {unassigned.map(s=>(
                  <option key={s.id} value={s.id}>{s.name} • {s.address}</option>
                ))}
              </select>
            </div>
            <div style={{flex:2}}>
              <label>Worker 1</label>
              <select value={form.worker1} onChange={e=>setForm({...form, worker1:e.target.value})}>
                <option value="">—</option>
                {workers.map(w=>(
                  <option key={w.email} value={w.email}>{w.name} ({w.email})</option>
                ))}
              </select>
            </div>
            <div style={{flex:2}}>
              <label>Worker 2</label>
              <select value={form.worker2} onChange={e=>setForm({...form, worker2:e.target.value})}>
                <option value="">—</option>
                {workers.map(w=>(
                  <option key={w.email} value={w.email}>{w.name} ({w.email})</option>
                ))}
              </select>
            </div>
            <div style={{flex:2}}>
              <label>Date &amp; Time</label>
              <input value={form.when} onChange={e=>setForm({...form, when:e.target.value})} placeholder="Tue 2:00–5:00 PM"/>
            </div>
          </div>
          <div className="toolbar">
            <button className="btn" onClick={doAssign}>Assign</button>
          </div>
        </div>
      </div>

      {/* Salesman snapshot (simple Mon–Sun) */}
      <div className="card">
        <h2 className="section-title">Salesman Snapshot</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Salesman</th>
              <th>Customers sold this week (names)</th>
              {DAYS.map(d=><th key={d}>{d}</th>)}
              <th>Remind</th>
            </tr>
          </thead>
          <tbody>
            {salesmanSnapshot.length===0 && <tr><td colSpan={11} style={{color:'#64748b'}}>No salesmen.</td></tr>}
            {salesmanSnapshot.map(s=>(
              <tr key={s.email}>
                <td>{s.name}</td>
                <td>{s.soldCount || 0}{s.soldNames?.length>0 ? ` (${s.soldNames.join(', ')})` : ''}</td>
                {DAYS.map(d=>(
                  <td key={d} style={{fontSize:12}}>{s.weekHours[d]||'-'}</td>
                ))}
                <td>
                  <button className="btn outline" onClick={()=>{
                    const nxt = nextShift(s.email,'seller')
                    pushReminder('Next Shift', nxt ? `${s.name} — ${nxt}` : `${s.name}: no upcoming hours found.`)
                  }}>Remind</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Worker snapshot (simple Mon–Sun) */}
      <div className="card">
        <h2 className="section-title">Worker Snapshot</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Worker</th><th>Scheduled?</th><th>Customer(s)</th><th>When (time &amp; date)</th>
              {DAYS.map(d=><th key={d}>{d}</th>)}
              <th>Remind</th>
            </tr>
          </thead>
          <tbody>
            {workerSnapshot.length===0 && <tr><td colSpan={13} style={{color:'#64748b'}}>No workers.</td></tr>}
            {workerSnapshot.map(w=>(
              <tr key={w.email}>
                <td>{w.name}</td>
                <td><span className="badge">{w.customers?.length>0 ? 'Yes':'No'}</span></td>
                <td>{w.customers?.length>0 ? w.customers.join(', ') : '-'}</td>
                <td>{w.whens?.length>0 ? w.whens.join(' • ') : '-'}</td>
                {DAYS.map(d=>(
                  <td key={d} style={{fontSize:12}}>{w.weekHours[d]||'-'}</td>
                ))}
                <td>
                  <button className="btn outline" onClick={()=>{
                    const nxt = nextShift(w.email,'worker')
                    pushReminder('Next Shift', nxt ? `${w.name} — ${nxt}` : `${w.name}: no upcoming hours found.`)
                  }}>Remind</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Future Assignments list */}
      <div className="card">
        <h2 className="section-title">Future Assignments</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Customer</th><th>Phone</th><th>Address</th><th>Salesman</th><th>Worker 1</th><th>Worker 2</th><th>When (date &amp; time)</th>
            </tr>
          </thead>
          <tbody>
            {assignments.length===0 && <tr><td colSpan={7} style={{color:'#64748b'}}>None yet.</td></tr>}
            {assignments.map(a=>{
              const sale = sales.find(s => String(s.id)===String(a.saleId))
              const w1 = users.find(u=>u.email===a.workerEmail)
              const w2 = users.find(u=>u.email===a.worker2Email)
              return (
                <tr key={a.id}>
                  <td>{sale ? sale.name : a.saleId}</td>
                  <td>{sale?.phone || '-'}</td>
                  <td>{sale?.address || '-'}</td>
                  <td>{sale ? `${sale.sellerName} (${sale.sellerEmail})` : '-'}</td>
                  <td>{w1 ? w1.name : a.workerEmail}</td>
                  <td>{w2 ? w2.name : a.worker2Email}</td>
                  <td>{a.when || '-'}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}