import React, { useEffect, useMemo, useState } from 'react'

/** ---------- storage helpers ---------- */
function readUsers(){ try{ return JSON.parse(localStorage.getItem('users_seed')||'[]') }catch{ return [] } }
function readAvailability(){ try{ return JSON.parse(localStorage.getItem('availability')||'[]') }catch{ return [] } }
function readNeighborhoods(){ try{ return JSON.parse(localStorage.getItem('neighborhoodAssignments')||'[]') }catch{ return [] } }
function writeNeighborhoods(rows){ localStorage.setItem('neighborhoodAssignments', JSON.stringify(rows)) }

/** ---------- dates (rolling week) ---------- */
const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
const startOfWeek = (d=new Date())=>{
  const x=new Date(d); const day=(x.getDay()+6)%7; x.setDate(x.getDate()-day); x.setHours(0,0,0,0); return x
}
const addDays = (d,n)=>{ const x=new Date(d); x.setDate(x.getDate()+n); return x }
const fmtDate = d=> new Date(d).toLocaleDateString([], {month:'short', day:'numeric'})
const fmtWeekLabel = (wkStart)=>`${fmtDate(wkStart)} – ${fmtDate(addDays(wkStart,6))}`
const monLabel = (jsDate)=> DAYS[(new Date(jsDate).getDay()+6)%7]

/** ---------- availability to show hours in cells ---------- */
function getWeeklyHours(email, role){
  const all = readAvailability()
  const mine = all.filter(a=>a.userEmail===email && a.role===role)
  const map = {}
  for(const d of DAYS){ map[d] = mine.find(m=>m.day===d)?.hours || '' }
  return map
}

/** ---------- notifications ---------- */
function notify(title, body){
  try{
    if (!('Notification' in window)) { alert(body); return }
    if (Notification.permission === 'granted'){ new Notification(title,{body}); return }
    if (Notification.permission !== 'denied'){
      Notification.requestPermission().then(p=>{
        if (p==='granted') new Notification(title,{body}); else alert(body)
      }); return
    }
    alert(body)
  }catch{ alert(body) }
}

/** =======================================================================
 *  Neighborhoods (Assign + Rolling Week View for ALL salesmen/admin/hybrid)
 *  ======================================================================= */
export default function Neighborhoods(){
  const users = readUsers()

  // Anyone who can receive neighborhoods: seller + hybrid + admin
  const salesPool = useMemo(
    ()=> users.filter(u=>u.role==='seller' || u.role==='hybrid' || u.role==='admin'),
    [users]
  )

  const [rows, setRows] = useState(readNeighborhoods())
  useEffect(()=>{ setRows(readNeighborhoods()) }, [])

  // --- Assign form (Salesman, Date & Time, Neighborhood, Notes) ---
  const [sellerEmail, setSellerEmail] = useState(salesPool[0]?.email || '')
  const [whenStr, setWhenStr]       = useState('')  // e.g., "Oct 28 2025 2:00 PM"
  const [neighborhood, setNeighborhood] = useState('')
  const [notes, setNotes] = useState('')

  const chosenSeller = useMemo(()=> salesPool.find(s=>s.email===sellerEmail) || null, [salesPool, sellerEmail])

  const onAssign = ()=>{
    if (!chosenSeller){ alert('Pick a salesman.'); return }
    if (!whenStr.trim()){ alert('Enter a date & time.'); return }
    if (!neighborhood.trim()){ alert('Enter a neighborhood.'); return }

    const dt = new Date(whenStr)
    if (isNaN(dt.getTime())){ alert('Invalid date/time. Try like "Oct 28 2025 2:00 PM".'); return }

    const wkStart = startOfWeek(dt)
    const record = {
      id: Date.now(),
      sellerEmail: chosenSeller.email,
      sellerName: chosenSeller.name,
      day: monLabel(dt),                  // Mon..Sun
      dateISO: dt.toISOString(),         // exact date/time
      weekStartISO: wkStart.toISOString(),
      neighborhood: neighborhood.trim(),
      notes: notes.trim(),
      assignedAt: Date.now(),
      worked: false,
      customersWorked: 0,                // editable in Admin → Previous
    }

    const next=[...rows, record]
    writeNeighborhoods(next); setRows(next)
    setNeighborhood(''); setNotes(''); setWhenStr('')

    notify('Neighborhood Assigned', `${chosenSeller.name} — ${record.day} ${fmtDate(dt)}: ${record.neighborhood}`)
  }

  // --- Rolling week selector for the table (all salesmen) ---
  const [weekStart, setWeekStart] = useState(()=>startOfWeek())
  const weekOptions = useMemo(()=>{
    const base = startOfWeek()
    return Array.from({length:8},(_,i)=> addDays(base, i*7)) // this week + next 7 weeks
  },[])

  // Group assignments by (email, weekStartISO, day)
  const gridLookup = useMemo(()=>{
    const map = new Map()
    for(const r of rows){
      const key = `${r.sellerEmail}|${r.weekStartISO}|${r.day}`
      map.set(key, r)
    }
    return map
  },[rows])

  return (
    <div className="grid">
      {/* Assign Neighborhood */}
      <div className="card">
        <h2 className="section-title">Assign Neighborhood</h2>
        <div className="row" style={{gap:12, flexWrap:'wrap'}}>
          <div style={{minWidth:260, flex:1}}>
            <label>Salesman</label>
            <select value={sellerEmail} onChange={e=>setSellerEmail(e.target.value)}>
              {salesPool.map(s=>(
                <option key={s.email} value={s.email}>{s.name} — {s.role}</option>
              ))}
            </select>
          </div>
          <div style={{minWidth:260, flex:1}}>
            <label>Date &amp; Time</label>
            <input
              placeholder="Oct 28 2025 2:00 PM"
              value={whenStr}
              onChange={e=>setWhenStr(e.target.value)}
            />
          </div>
          <div style={{minWidth:260, flex:1}}>
            <label>Neighborhood</label>
            <input placeholder="e.g., Westlake" value={neighborhood} onChange={e=>setNeighborhood(e.target.value)} />
          </div>
        </div>
        <div className="grid" style={{marginTop:10}}>
          <label>Notes</label>
          <textarea rows={2} value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Optional details for this assignment..." />
          <div className="toolbar">
            <button className="btn" onClick={onAssign}>Assign + Notify</button>
          </div>
        </div>
      </div>

      {/* Rolling Week View — ALL salesmen/hybrid/admin */}
      <div className="card">
        <div className="row" style={{justifyContent:'space-between', alignItems:'center'}}>
          <h2 className="section-title" style={{margin:0}}>Week View — All Salesmen</h2>
          <div style={{minWidth:240}}>
            <label>Week</label>
            <select
              value={startOfWeek(weekStart).toISOString()}
              onChange={e=>setWeekStart(new Date(e.target.value))}
            >
              {weekOptions.map(d=>(
                <option key={d.toISOString()} value={d.toISOString()}>
                  {fmtWeekLabel(d)}
                </option>
              ))}
            </select>
          </div>
        </div>

        <table className="table">
          <thead>
            <tr>
              <th>Salesman</th>
              {DAYS.map(d=> <th key={d}>{d}</th>)}
            </tr>
          </thead>
          <tbody>
            {salesPool.length===0 && <tr><td colSpan={8} style={{color:'#64748b'}}>No salesmen.</td></tr>}
            {salesPool.map(s=>{
              const hours = getWeeklyHours(s.email, 'seller')
              return (
                <tr key={s.email}>
                  <td>{s.name} <span className="badge" style={{marginLeft:6}}>{s.role}</span></td>
                  {DAYS.map(d=>{
                    const hit = gridLookup.get(`${s.email}|${startOfWeek(weekStart).toISOString()}|${d}`)
                    return (
                      <td key={d} style={{fontSize:12}}>
                        {hours[d] || '-'}
                        {hit && (
                          <div style={{fontSize:11, opacity:.8, marginTop:2}}>
                            {hit.neighborhood || '-'}
                          </div>
                        )}
                      </td>
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* NOTE: Per your request, the Neighborhood History LIST was removed from this tab. */}
    </div>
  )
}