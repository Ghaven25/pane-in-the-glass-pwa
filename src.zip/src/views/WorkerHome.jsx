// src/views/WorkerHome.jsx
import React, { useMemo, useState } from "react";

function getUser(){ try{ return JSON.parse(localStorage.getItem("pane_user")||"null") }catch{ return null } }
function readAvail(){ try{ return JSON.parse(localStorage.getItem("availability")||"[]") }catch{ return [] } }
function readAssignments(){ try{ return JSON.parse(localStorage.getItem("assignments")||"[]") }catch{ return [] } }
function writeAssignments(rows){ localStorage.setItem("assignments", JSON.stringify(rows)) }
function readSales(){ try{ return JSON.parse(localStorage.getItem("sales")||"[]") }catch{ return [] } }
function readUsers(){ try{ return JSON.parse(localStorage.getItem("users_seed")||"[]") }catch{ return [] } }

function startOfDay(d){ const x=new Date(d); x.setHours(0,0,0,0); return x }
function addDays(d,n){ const x=new Date(d); x.setDate(x.getDate()+n); return x }
function fmtDay(d){ return d.toLocaleDateString([], { weekday:"short", month:"short", day:"numeric" }) }
function shortDow(d){ return d.toLocaleDateString([], { weekday:"short" }) }

export default function WorkerHome(){
  const me = getUser();
  const users = readUsers();

  const [avail] = useState(readAvail());
  const [assignments, setAssignments] = useState(readAssignments());
  const sales = readSales();

  const days = useMemo(()=>{
    const t = startOfDay(new Date());
    return Array.from({length:7}, (_,i)=> addDays(t,i));
  },[]);

  const getHours = (dayLabel)=>{
    const row = avail.find(a=>a.userEmail===me?.email && a.role==="worker" && a.day===dayLabel);
    return row?.hours || "";
  };

  const getNameByEmail = (email)=> users.find(u=>u.email===email)?.name || email || '-';

  // UPCOMING ASSIGNMENTS
  const upcoming = useMemo(()=>{
    const mine = assignments.filter(a => (a.workerEmail===me?.email || a.worker2Email===me?.email) && a.status !== 'offered');
    return mine.map(a=>{
      const sale = sales.find(s=>String(s.id)===String(a.saleId));
      const other = a.workerEmail===me?.email ? a.worker2Email : a.workerEmail;
      const price = sale?.price ? Number(sale.price) : null;
      const myShare = price!=null ? `$${(price*0.2).toFixed(2)}` : '-';
      return {
        id:a.id,
        customer: sale?.name || a.saleId,
        address: sale?.address || '-',
        when: a.when || '-',
        otherWorker: other ? getNameByEmail(other) : '-',
        myMoney: myShare
      }
    });
  }, [assignments, sales, me?.email]);

  // OFFERED ASSIGNMENTS
  const offered = useMemo(()=>{
    return assignments.filter(a=>{
      const meOnOffer = Array.isArray(a.offeredTo) && a.offeredTo.includes(me?.email);
      return a.status === 'offered' && meOnOffer;
    }).map(a=>{
      const sale = sales.find(s=>String(s.id)===String(a.saleId));
      const price = sale?.price ? Number(sale.price) : null;
      const myShare = price!=null ? `$${(price*0.2).toFixed(2)}` : '-';
      const other = a.workerEmail && a.workerEmail!==me?.email ? a.workerEmail
                  : (a.worker2Email && a.worker2Email!==me?.email ? a.worker2Email : null);
      return {
        id:a.id,
        customer:sale?.name || a.saleId,
        address:sale?.address || '-',
        when:a.when || '-',
        otherWorker: other ? getNameByEmail(other) : '-',
        myMoney: myShare
      }
    });
  },[assignments, sales, me?.email]);

  const acceptOffer = (id)=>{
    const all = readAssignments();
    const idx = all.findIndex(a=>a.id===id);
    if(idx===-1) return;
    const a = all[idx];
    let workerEmail = a.workerEmail;
    let worker2Email = a.worker2Email;
    if(!workerEmail && !worker2Email){ workerEmail = me.email; }
    else if(workerEmail && !worker2Email){ worker2Email = me.email; }
    else if(!workerEmail && worker2Email){ workerEmail = me.email; }
    const updated = { ...a, workerEmail, worker2Email, status:'assigned', offeredTo:(a.offeredTo||[]).filter(e=>e!==me.email) };
    all[idx]=updated; writeAssignments(all); setAssignments(all);
    alert('Offer accepted.');
  };

  const [denyId, setDenyId] = useState(null);
  const [denyNotes, setDenyNotes] = useState('');
  const openDeny = (id)=>{ setDenyId(id); setDenyNotes(''); }
  const cancelDeny = ()=>{ setDenyId(null); setDenyNotes(''); }
  const submitDeny = ()=>{
    if(!denyNotes.trim()){ alert('Please enter a reason.'); return; }
    const all = readAssignments();
    const idx = all.findIndex(a=>a.id===denyId);
    if(idx===-1) return;
    const a = all[idx];
    const updated = { ...a, denied:[...(a.denied||[]),{email:me.email,reason:denyNotes.trim(),ts:Date.now()}], offeredTo:(a.offeredTo||[]).filter(e=>e!==me.email) };
    all[idx]=updated; writeAssignments(all); setAssignments(all);
    setDenyId(null); setDenyNotes('');
    alert('Offer denied.');
  };

  const byWeekday = useMemo(()=>{
    const mine = assignments.filter(a=>(a.status!=='offered')&&(a.workerEmail===me?.email||a.worker2Email===me?.email));
    const map={}; const keys=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    for(const a of mine){
      const sale=sales.find(s=>String(s.id)===String(a.saleId));
      const label=a.when||''; const key=keys.find(k=>label.toLowerCase().includes(k.toLowerCase()));
      if(!key) continue;
      (map[key] ||= []).push({customer:sale?.name||a.saleId, when:a.when||'-'});
    }
    return map;
  }, [assignments, sales, me?.email]);

  return (
    <div className="grid">
      {/* Upcoming */}
      <div className="card">
        <h2 className="section-title">My Upcoming Assignments</h2>
        <table className="table">
          <thead><tr><th>Customer</th><th>Address</th><th>Date &amp; Time</th><th>Other Worker</th><th>Money for You</th></tr></thead>
          <tbody>
            {upcoming.length===0 && <tr><td colSpan={5} style={{color:'#8fb7c9'}}>No upcoming assignments.</td></tr>}
            {upcoming.map(r=>(
              <tr key={r.id}><td>{r.customer}</td><td>{r.address}</td><td>{r.when}</td><td>{r.otherWorker}</td><td>{r.myMoney}</td></tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Offered */}
      <div className="card">
        <h2 className="section-title">Offered Assignments</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Customer</th>
              <th>Address</th>
              <th>Date &amp; Time</th>
              <th>Other Worker</th>
              <th>Money for You</th>
              <th>Accept</th>
              <th>Deny</th>
            </tr>
          </thead>
          <tbody>
            {offered.length===0 && <tr><td colSpan={7} style={{color:'#8fb7c9'}}>No offers.</td></tr>}
            {offered.map(o=>(
              <tr key={o.id}>
                <td>{o.customer}</td>
                <td>{o.address}</td>
                <td>{o.when}</td>
                <td>{o.otherWorker}</td>
                <td>{o.myMoney}</td>
                <td><button className="btn" onClick={()=>acceptOffer(o.id)}>Accept</button></td>
                <td><button className="btn outline" onClick={()=>openDeny(o.id)}>Deny</button></td>
              </tr>
            ))}
          </tbody>
        </table>

        {denyId!=null && (
          <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.5)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:50}}>
            <div className="card" style={{width:420, maxWidth:'90vw'}}>
              <h3 className="section-title" style={{marginTop:0}}>Why are you denying?</h3>
              <textarea rows={4} value={denyNotes} onChange={e=>setDenyNotes(e.target.value)} placeholder="Type the reason..." />
              <div className="row" style={{justifyContent:'flex-end', marginTop:10}}>
                <button className="btn outline" onClick={cancelDeny}>Cancel</button>
                <button className="btn" onClick={submitDeny}>Submit</button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Weekly Hours */}
      <div className="card">
        <h2 className="section-title">My Weekly Hours (Next 7 Days) — Scheduled</h2>
        <table className="table">
          <thead><tr>{days.map(d=><th key={d.toISOString()}>{fmtDay(d)}</th>)}</tr></thead>
          <tbody>
            <tr>
              {days.map(d=>{
                const short=shortDow(d).slice(0,3);
                const value=getHours(short);
                const items=byWeekday[short]||[];
                return(
                  <td key={d.toISOString()}>
                    <input value={value} readOnly disabled style={{width:'100%',opacity:.8,cursor:'not-allowed'}}/>
                    {items.length>0 && <div style={{marginTop:6,fontSize:12,color:'#8fb7c9'}}>{items.map((o,i)=><div key={i}>• {o.customer} — {o.when}</div>)}</div>}
                  </td>
                );
              })}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}