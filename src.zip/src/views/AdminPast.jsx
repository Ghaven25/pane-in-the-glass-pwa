import React, { useEffect, useMemo, useState } from 'react'

/** storage */
function readSales(){ try{ return JSON.parse(localStorage.getItem('sales')||'[]') }catch{ return [] } }
function readAssignments(){ try{ return JSON.parse(localStorage.getItem('assignments')||'[]') }catch{ return [] } }
function readUsers(){ try{ return JSON.parse(localStorage.getItem('users_seed')||'[]') }catch{ return [] } }

function readNeighborhoods(){ try{ return JSON.parse(localStorage.getItem('neighborhoodAssignments')||'[]') }catch{ return [] } }
function writeNeighborhoods(rows){ localStorage.setItem('neighborhoodAssignments', JSON.stringify(rows)) }

const fmtDate = t => new Date(t).toLocaleString([], {month:'short', day:'numeric', hour:'numeric', minute:'2-digit'})
const fmtDateOnly = t => new Date(t).toLocaleDateString([], {month:'short', day:'numeric'})

export default function AdminPast(){
  const [sales, setSales] = useState(readSales())
  const [assignments, setAssignments] = useState(readAssignments())
  const [neigh, setNeigh] = useState(readNeighborhoods())
  const users = readUsers()

  useEffect(()=>{
    setSales(readSales()); setAssignments(readAssignments()); setNeigh(readNeighborhoods())
  },[])

  const onCustomersWorkedChange = (id, val)=>{
    const num = Math.max(0, Number.isFinite(+val) ? +val : 0)
    const next = neigh.map(r => r.id===id ? {...r, customersWorked: num} : r)
    writeNeighborhoods(next); setNeigh(next)
  }

  const neighborhoodHistory = useMemo(()=>{
    return [...neigh].sort((a,b)=> (new Date(b.assignedAt)) - (new Date(a.assignedAt)))
  },[neigh])

  const previousAssignments = useMemo(()=> assignments.filter(a=>{
    if (!a.when) return false
    return new Date(a.when).getTime() < Date.now()
  }), [assignments])

  return (
    <div className="grid">

      {/* Neighborhood History (UPDATED COLUMNS) */}
      <div className="card">
        <h2 className="section-title">Neighborhood History</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Salesman</th>
              <th>Date(s)</th>
              <th>Neighborhood</th>
              <th style={{width:140}}>Customers Worked</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {neighborhoodHistory.length===0 && (
              <tr><td colSpan={5} style={{color:'#64748b'}}>No neighborhood assignments yet.</td></tr>
            )}
            {neighborhoodHistory.map(r=>(
              <tr key={r.id}>
                <td>{r.sellerName} ({r.sellerEmail})</td>
                <td>
                  {r.day || '-'} • {r.dateISO ? fmtDateOnly(r.dateISO) : '-'}
                </td>
                <td>{r.neighborhood || '-'}</td>
                <td>
                  <input
                    inputMode="numeric"
                    style={{width:100}}
                    value={typeof r.customersWorked==='number' ? r.customersWorked : 0}
                    onChange={e=>onCustomersWorkedChange(r.id, e.target.value)}
                  />
                </td>
                <td style={{fontSize:12, color:'#334155'}}>{r.notes || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Minimal Previous Assignments (keep or replace with your own) */}
      <div className="card">
        <h2 className="section-title">Previous Assignments</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Date & Time</th>
              <th>Customer</th>
              <th>Salesman</th>
              <th>Worker 1</th>
              <th>Worker 2</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {previousAssignments.length===0 && <tr><td colSpan={6} style={{color:'#64748b'}}>None yet.</td></tr>}
            {previousAssignments.map(a=>{
              const sale = sales.find(s=>String(s.id)===String(a.saleId))
              const w1 = users.find(u=>u.email===a.workerEmail)
              const w2 = users.find(u=>u.email===a.worker2Email)
              return (
                <tr key={a.id}>
                  <td>{a.when || '-'}</td>
                  <td>{sale ? sale.name : a.saleId}</td>
                  <td>{sale ? sale.sellerName : '-'}</td>
                  <td>{w1 ? w1.name : a.workerEmail}</td>
                  <td>{w2 ? w2.name : a.worker2Email}</td>
                  <td><span className="badge">worked?</span></td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* Minimal Customer History (optional) */}
      <div className="card">
        <h2 className="section-title">Customer History</h2>
        <table className="table" style={{fontSize:12}}>
          <thead>
            <tr>
              <th>Name</th>
              <th>Salesman</th>
              <th>Date Sold</th>
              <th>Date Worked</th>
              <th>Address</th>
              <th>Paid?</th>
              <th>Amount</th>
              <th>Phone</th>
              <th>Neighborhood</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {sales.length===0 && <tr><td colSpan={10} style={{color:'#64748b'}}>No customers yet.</td></tr>}
            {sales
              .sort((a,b)=> (new Date(b.createdAt||0)) - (new Date(a.createdAt||0)))
              .map(s=>(
                <tr key={s.id}>
                  <td>{s.name}</td>
                  <td>{s.sellerName || '-'}</td>
                  <td>{s.createdAt ? fmtDateOnly(s.createdAt) : '-'}</td>
                  <td>{s.when ? fmtDateOnly(s.when) : '-'}</td>
                  <td>{s.address || '-'}</td>
                  <td>{s.paid ? 'Yes' : 'No'}</td>
                  <td>{s.price ? `$${s.price}` : '-'}</td>
                  <td>{s.phone || '-'}</td>
                  <td>{s.neighborhood || '-'}</td>
                  <td style={{maxWidth:260, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{s.notes || '-'}</td>
                </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}