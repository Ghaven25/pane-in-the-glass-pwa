// src/ui/Header.jsx
import React from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'

function getUser(){ try{return JSON.parse(localStorage.getItem('pane_user')||'null')}catch{return null} }

export default function Header(){
  const nav = useNavigate()
  const loc = useLocation()
  const user = getUser()
  if(!user) return null

  const isActive = (p) => loc.pathname === p
  const tabCls = (p) => isActive(p) ? 'tab active' : 'tab'

  const showAdmin  = user.role === 'admin'
  const showSeller = user.role === 'seller' || user.role === 'hybrid' || user.role === 'admin'
  const showWorker = user.role === 'worker' || user.role === 'hybrid' || user.role === 'admin'

  const toggleTheme = ()=>{
    const cur = document.documentElement.getAttribute('data-theme') || 'dark'
    const next = cur === 'dark' ? 'light' : 'dark'
    document.documentElement.setAttribute('data-theme', next)
    localStorage.setItem('theme', next)
  }

  React.useEffect(()=>{
    const saved = localStorage.getItem('theme') || 'dark'
    document.documentElement.setAttribute('data-theme', saved)
  },[])

  const logout = () => {
    localStorage.removeItem('pane_user')
    nav('/', { replace:true })
  }

  const logoSrc = (import.meta && import.meta.env && import.meta.env.BASE_URL ? import.meta.env.BASE_URL : '/') + 'logo.png'

  return (
    <header className="topbar">
      <div className="brandWrap">
        <img src={logoSrc} alt="" className="logo" />
        <div className="brandLeft">Pane in The Glass</div>
      </div>

      <nav className="tabs">
        {showAdmin && (
          <>
            <Link to="/admin" className={tabCls('/admin')}>Admin (Future)</Link>
            <Link to="/admin/past" className={tabCls('/admin/past')}>Admin (Previous)</Link>
            <Link to="/employees" className={tabCls('/employees')}>Employees</Link>
            <Link to="/calendar/workers" className={tabCls('/calendar/workers')}>Workers Calendar</Link>
            <Link to="/calendar/sellers" className={tabCls('/calendar/sellers')}>Sellers Calendar</Link>
            <Link to="/neighborhoods" className={tabCls('/neighborhoods')}>Neighborhoods</Link>
            <Link to="/money" className={tabCls('/money')}>Money</Link>
          </>
        )}

        {showSeller && (
          <Link to="/seller" className={tabCls('/seller')}>Sales</Link>
        )}

        {showWorker && (
          <>
            <Link to="/worker" className={tabCls('/worker')}>My Jobs</Link>
            <Link to="/calendar/workers" className={tabCls('/calendar/workers')}>My Calendar</Link>
            <Link to="/worker/finished" className={tabCls('/worker/finished')}>Finished Job</Link>
            <Link to="/worker/payments" className={tabCls('/worker/payments')}>Payments</Link>
          </>
        )}
      </nav>

      <div className="right">
        <span className="chip">{user.name} ({user.role})</span>
        <button className="btn outline" onClick={toggleTheme}>Toggle Theme</button>
        <button className="btn outline" onClick={logout}>Logout</button>
      </div>
    </header>
  )
}