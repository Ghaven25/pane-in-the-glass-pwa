import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

// Seed users in local (simple mode)
const seededUsers = [
  { role:'admin',  email:'ghavenkm25@gmail.com',             pin:'1234', name:'Ghaven' },
  { role:'worker', email:'timetoeatplayer25@gmail.com',      pin:'4321', name:'Gavin'  },
  { role:'seller', email:'kidsfixpaneintheglass@gmail.com',  pin:'1357', name:'Sam'    },
  // hybrid gets both seller + worker access (lands on Seller by default)
  { role:'hybrid', email:'clash.ghaven2.0@gmail.com',        pin:'2468', name:'Chad'   },
]

export default function Login(){
  const nav = useNavigate()
  const [email, setEmail] = useState('')
  const [pin, setPin]       = useState('')

  const onLogin = () => {
    const e = (email || '').trim().toLowerCase()
    const p = (pin || '').trim()
    const user = seededUsers.find(u => u.email.toLowerCase() === e && u.pin === p)
    if (user) {
      localStorage.setItem('pane_user', JSON.stringify(user))
      localStorage.setItem('users_seed', JSON.stringify(seededUsers)) // so Admin can see list
      if (user.role === 'admin') nav('/admin')
      else if (user.role === 'seller' || user.role === 'hybrid') nav('/seller')
      else if (user.role === 'worker') nav('/worker')
      else nav('/')
    } else {
      alert('Invalid email or PIN')
    }
  }

  return (
    <div className="login-wrap">
      <div className="card">
        <h1 className="brand">Pane in The Glass</h1>
        <p className="muted">Sign in with your email + 4-digit PIN</p>

        <label>Email</label>
        <input
          value={email}
          onChange={e=>setEmail(e.target.value)}
          placeholder="you@example.com"
          inputMode="email"
          autoCapitalize="none"
        />

        <label style={{marginTop:8}}>PIN</label>
        <input
          value={pin}
          onChange={e=>setPin(e.target.value)}
          placeholder="4 digits"
          maxLength={6}
          inputMode="numeric"
        />

        <div className="toolbar">
          <button className="btn" onClick={onLogin}>Continue</button>
        </div>

        <div className="sample-logins">
          <div>Admin: <code>ghavenkm25@gmail.com</code> / <code>1234</code></div>
          <div>Seller: <code>kidsfixpaneintheglass@gmail.com</code> / <code>1357</code></div>
          <div>Worker: <code>timetoeatplayer25@gmail.com</code> / <code>4321</code></div>
          <div>Hybrid: <code>clash.ghaven2.0@gmail.com</code> / <code>2468</code></div>
        </div>
      </div>
    </div>
  )
}