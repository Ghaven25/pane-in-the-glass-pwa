import React, { useState } from "react";

export default function App() {
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("");
  const [name, setName] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    if (!email || !role || !name) {
      alert("Please enter your name, email, and select a role.");
      return;
    }

    const user = { name, email, role };
    localStorage.setItem("pane_user", JSON.stringify(user));
    window.location.href =
      role === "admin"
        ? "/admin"
        : role === "worker"
        ? "/worker"
        : role === "seller"
        ? "/seller"
        : "/";
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100vh",
        background: "#f8fafc",
        fontFamily: "sans-serif",
      }}
    >
      <div
        style={{
          background: "#fff",
          padding: "40px 50px",
          borderRadius: 12,
          boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
          width: "340px",
        }}
      >
        <h2 style={{ textAlign: "center", marginBottom: 20 }}>
          Pane in the Glass Login
        </h2>

        <form onSubmit={handleLogin}>
          <label style={{ display: "block", marginBottom: 6 }}>Name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Your name"
            style={{
              width: "100%",
              padding: 8,
              marginBottom: 12,
              borderRadius: 6,
              border: "1px solid #cbd5e1",
            }}
          />

          <label style={{ display: "block", marginBottom: 6 }}>Email</label>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            style={{
              width: "100%",
              padding: 8,
              marginBottom: 12,
              borderRadius: 6,
              border: "1px solid #cbd5e1",
            }}
          />

          <label style={{ display: "block", marginBottom: 6 }}>Role</label>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value)}
            style={{
              width: "100%",
              padding: 8,
              marginBottom: 20,
              borderRadius: 6,
              border: "1px solid #cbd5e1",
            }}
          >
            <option value="">Select Role</option>
            <option value="admin">Admin</option>
            <option value="worker">Worker</option>
            <option value="seller">Seller</option>
            <option value="hybrid">Hybrid</option>
          </select>

          <button
            type="submit"
            style={{
              width: "100%",
              padding: "10px",
              background: "#2563eb",
              color: "white",
              border: "none",
              borderRadius: 6,
              cursor: "pointer",
            }}
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
}