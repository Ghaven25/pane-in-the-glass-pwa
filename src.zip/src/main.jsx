// src/main.jsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'

import Header from './ui/Header.jsx'

import AdminAssign from './views/AdminAssign.jsx'
import AdminPast from './views/AdminPast.jsx'
import Employees from './views/Employees.jsx'
import MoneyTab from './views/MoneyTab.jsx'
import WorkersCalendar from './views/WorkersCalendar.jsx'
import SellersCalendar from './views/SellersCalendar.jsx'
import Neighborhoods from './views/Neighborhoods.jsx'
import Sales from './views/Sales.jsx'
import WorkerHome from './views/WorkerHome.jsx'
import WorkerPayments from './views/WorkerPayments.jsx'
import FinishedJob from './views/FinishedJob.jsx'

import './ui/header.css'

function getUser() {
  try { return JSON.parse(localStorage.getItem('pane_user') || 'null') } catch { return null }
}

function defaultRouteFor(user) {
  if (!user) return '/'
  switch (user.role) {
    case 'admin': return '/admin'
    case 'seller': return '/seller'
    case 'worker': return '/worker'
    case 'hybrid': return '/admin'
    default: return '/'
  }
}

function Login() {
  const [email, setEmail] = React.useState('')
  const [pin, setPin] = React.useState('')

  const nav = (path) => {
    window.history.pushState({}, '', path)
    window.dispatchEvent(new PopStateEvent('popstate'))
  }

  const seededUsers = JSON.parse(localStorage.getItem('users_seed') || 'null') || [
    { role: 'admin', email: 'ghavenkm25@gmail.com', pin: '1234', name: 'Ghaven', phone: '', address: '' },
    { role: 'worker', email: 'timetoeatplayer25@gmail.com', pin: '4321', name: 'Gavin', phone: '', address: '' },
    { role: 'seller', email: 'kidsfixpaneintheglass@gmail.com', pin: '1357', name: 'Sam', phone: '', address: '' },
    { role: 'hybrid', email: 'clash.ghaven2.0@gmail.com', pin: '2468', name: 'Chad', phone: '', address: '' },
  ]

  React.useEffect(() => {
    if (!localStorage.getItem('users_seed')) {
      localStorage.setItem('users_seed', JSON.stringify(seededUsers))
    }
  }, [])

  const onLogin = () => {
    const e = (email || '').trim().toLowerCase()
    const p = (pin || '').trim()
    const users = JSON.parse(localStorage.getItem('users_seed') || '[]')
    const user = users.find(u => (u.email || '').toLowerCase() === e && u.pin === p)
    if (user) {
      localStorage.setItem('pane_user', JSON.stringify(user))
      nav(defaultRouteFor(user))
    } else {
      alert('Invalid email or PIN')
    }
  }

  return (
    <div className="login-wrap">
      <div className="card">
        <h1 className="brand">Pane in The Glass</h1>
        <p className="muted">Sign in with your email + 4-digit PIN</p>
        <label>Email</label>
        <input value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" />
        <label style={{ marginTop: 8 }}>PIN</label>
        <input value={pin} onChange={e => setPin(e.target.value)} placeholder="4 digits" inputMode="numeric" maxLength={6} />
        <div className="toolbar"><button className="btn" onClick={onLogin}>Continue</button></div>
      </div>
    </div>
  )
}

function RequireAuth({ children, allow }) {
  const user = getUser()
  const loc = useLocation()
  if (!user) return <Navigate to="/" state={{ from: loc }} replace />
  const hybridCan = allow?.some(r => r === 'seller' || r === 'worker' || r === 'admin')
  if (allow && !allow.includes(user.role) && !(user.role === 'hybrid' && hybridCan)) {
    return <Navigate to={defaultRouteFor(user)} replace />
  }
  return (<><Header /><div className="page">{children}</div></>)
}

function Home() {
  const user = getUser()
  if (!user) return <Login />
  return <Navigate to={defaultRouteFor(user)} replace />
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />

        {/* Admin */}
        <Route path="/admin" element={<RequireAuth allow={['admin', 'hybrid']}><AdminAssign /></RequireAuth>} />
        <Route path="/admin/past" element={<RequireAuth allow={['admin', 'hybrid']}><AdminPast /></RequireAuth>} />
        <Route path="/employees" element={<RequireAuth allow={['admin', 'hybrid']}><Employees /></RequireAuth>} />
        <Route path="/calendar/workers" element={<RequireAuth allow={['admin', 'hybrid', 'worker']}><WorkersCalendar /></RequireAuth>} />
        <Route path="/calendar/sellers" element={<RequireAuth allow={['admin', 'hybrid', 'seller']}><SellersCalendar /></RequireAuth>} />
        <Route path="/neighborhoods" element={<RequireAuth allow={['admin', 'hybrid']}><Neighborhoods /></RequireAuth>} />
        <Route path="/money" element={<RequireAuth allow={['admin', 'hybrid']}><MoneyTab /></RequireAuth>} />

        {/* Seller */}
        <Route path="/seller" element={<RequireAuth allow={['seller', 'hybrid', 'admin']}><Sales /></RequireAuth>} />

        {/* Worker */}
        <Route path="/worker" element={<RequireAuth allow={['worker', 'hybrid', 'admin']}><WorkerHome /></RequireAuth>} />
        <Route path="/worker/finished" element={<RequireAuth allow={['worker', 'hybrid', 'admin']}><FinishedJob /></RequireAuth>} />
        <Route path="/worker/payments" element={<RequireAuth allow={['worker', 'hybrid', 'admin']}><WorkerPayments /></RequireAuth>} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
)